namespace ConversorCalculator
{
    public abstract class InputValidator
    {
        public abstract void validate(string input);
    }
}